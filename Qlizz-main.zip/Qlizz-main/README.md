# FREE INSTAGRAM FOLLOWERS - WITH TERMUX
<div align="center">
  <img src="Data/Qlizz.jpg">
  <br>
  <br>
  <p>
    <img alt="GitHub contributors" src="https://img.shields.io/github/contributors/rozhakxd/Qlizz">
    <img alt="GitHub issues" src="https://img.shields.io/github/issues/rozhakxd/Qlizz">
    <img src="https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=shields">
    <img alt="GitHub pull requests" src="https://img.shields.io/github/issues-pr/rozhakxd/Qlizz">
    <img alt="GitHub commit activity" src="https://img.shields.io/github/commit-activity/m/rozhakxd/Qlizz">
    <img alt="Maintenance" src="https://img.shields.io/maintenance/no/2023">
  </p>
  <h4> Get Instagram Followers Without Login ! </h4>
</div>

##

### What is Qlizz?
[**Qlizz**](https://github.com/RozhakXD/Qlizz) is a script to get followers on Instagram accounts for free and without logging in. Qlizz is also very easy and takes only seconds for all followers to arrive.

### Termux command?
First you must have the [Termux](https://f-droid.org/repo/com.termux_118.apk) application to run this tool and for how to use it can be seen on [**Youtube**](https://youtu.be/fsntveOKzsQ). Then you enter some basic commands below!
```
$ apt update -y && apt upgrade -y
$ pkg install git python-pip
$ git clone https://github.com/RozhakXD/Qlizz
$ cd "Qlizz"
$ python -m pip install -r requirements.txt
$ python Run.py
```

```
$ cd "$HOME/Qlizz" && git pul
$ python Run.py
```

##

### Why failed to login?

- You must enter a fake password if asked to enter your Instagram account password.
- Maybe you haven't entered your username before getting cookies.
- You see no way to get cookies on youtube.
- The cookies you are using have expired. Each cookies is valid only every 3 days.

### Followers not coming?

- Maybe the qlizz website is being repaired or has an error.
- The username you enter when taking cookies is different from the one you entered in Termux.
- Your Instagram account is locked or private.
- The username you entered is not available or incorrect.

### Changing Qlizz cookies?

```
$ cd $HOME/Qlizz
$ rm Data/Cookie.json
$ python Run.py
```

### How long?

**Followers arrived :**
- This time depends on the number of users on the Qlizz website, sometimes it can take up to 24 hours for all followers to arrive.
- Each follower send takes 10 minutes for all followers to arrive in the account.

**Pause to send :**
- The delay for sending the next follower is 120 minutes or every two hours, sometimes it can reach 3 hours, it all depends on the Qlizz website.

##

```python
print("Good luck hope it works!")
```
##
